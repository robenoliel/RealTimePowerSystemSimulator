# -*- coding: utf-8 -*-
"""
Created on Tue Dec  8 20:36:21 2020

@author: roben
"""


###################### GENERATES FILE MAIN_CORE.H ############################

class File_main_core_h:
    
    def __init__(self, netList, integrationPass = 0.000005, pi = 3.1415926):
        self.integrationPass = integrationPass
        self.pi = pi
        self.netList = netList
        
        try:
            self.main_string = open('Script Pipeline\\HLStemplates//main_core_h.txt','r').read() #Gets the template
        except IOError:
            raise Exception('main_core.h file template not found!')
        
        self.countLC = 0
        self.countI = 0
        self.countV = 0
        self.countNodes = 0
        self.matrixOrder = 0
        
        for element in self.netList:
            kind = element[2][0]
            if kind == 'C' or kind == 'L':
                self.countLC += 1
            elif kind == 'I':
                self.countI += 1
            elif kind == 'V' or kind == 'A':
                self.countV += 1
            if element[0] > self.countNodes:
                self.countNodes = element[0]
        self.matrixOrder = self.countV + self.countNodes
        
        indexes = "\n#define A 0\n#define B 1\n#define C 2\n#define D 3"
        if self.matrixOrder < 4:
            indexes = indexes[0:1+12*self.matrixOrder]
        
        output = "\nfloat a;\nfloat b;\nfloat c;\nfloat d;"
        if self.matrixOrder < 4:
            output = output[0:1+9*self.matrixOrder]

        position = self.main_string.find('//it refers to the output address for the require information')
        position += len('//it refers to the output address for the require information')
        self.main_string = self.main_string[:position] + indexes + self.main_string[position:]
        
        position = self.main_string.find('struct OUTPUT{')
        position += len('struct OUTPUT{')
        self.main_string = self.main_string[:position] + output + self.main_string[position:]
        
        self.main_string = self.main_string % (self.countLC, self.countI, self.countV, self.countNodes, self.matrixOrder, self.integrationPass, self.pi)
        
    def get_main_string(self):
        return self.main_string
    
###################### GENERATES FILE MAIN_CORE.CPP ##########################

    
class File_main_core_cpp:
    
    def __init__(self, netList, Am, h):
        self.netList = netList
        self.Am = Am
        self.h = h
        
        try:
            self.main_string = open('Script Pipeline\\HLStemplates//main_core_cpp.txt','r').read() #Gets the template
        except IOError:
            raise Exception('main_core.cpp file template not found!')
        
        self.sourceI = []
        self.sourceV = []
        self.LC = []
        
        for line in netList:
            kind = line[2][0]
            if kind == 'I':
                self.sourceI.append([line[0], line[1], 0, 0, 0, line[3]])
            elif kind == 'V':
                self.sourceV.append([line[0], line[1], 0, 0, 0, line[3]])
            elif kind == 'A':
                self.sourceV.append([line[0], line[1], line[3]*h, line[4], line[5], line[3]])
            elif kind == 'L' or kind == 'C':
                self.LC.append([{'L':1, 'C':0}[kind], line[0], line[1], {'L':h/(2*line[3]), 'C':2*line[3]/h}[kind]])
            
        position = self.main_string.find('static I_SOURCE i_sources[I_SOURCES] = ')
        position += len('static I_SOURCE i_sources[I_SOURCES] = ')
        self.main_string = self.main_string[:position] + self.__cppMatrix(self.sourceI) + self.main_string[position:]
        
        position = self.main_string.find('static V_SOURCE sources[V_SOURCES] = ')
        position += len('static V_SOURCE sources[V_SOURCES] = ')
        self.main_string = self.main_string[:position] + self.__cppMatrix(self.sourceV) + self.main_string[position:]
        
        position = self.main_string.find('const MATRIX_G Gi[N][N] = ')
        position += len('const MATRIX_G Gi[N][N] = ')
        self.main_string = self.main_string[:position] + self.__cppMatrix(self.Am) + self.main_string[position:]
        
        position = self.main_string.find('static LC_ELEMENT elements[N_LC] = ')
        position += len('static LC_ELEMENT elements[N_LC] = ')
        self.main_string = self.main_string[:position] + self.__cppMatrix(self.LC) + self.main_string[position:]
                
    def __cppMatrix(self, matrix):
        stringMatrix = "\n{"
        firstLine = True
        for line in matrix:
            if not firstLine:
                stringMatrix += ',\n'
            else:
                firstLine = False
            stringMatrix += "{"
            firstColumn = True
            for element in line:
                if not firstColumn:
                    stringMatrix += ', '
                else:
                    firstColumn = False
                stringMatrix += '%.8e' % (element)
            stringMatrix += '}'
        stringMatrix += '}'
        return stringMatrix

    def get_main_string(self):
        return self.main_string
    

###################### GENERATES FILE MAIN_CORE_TB.CPP ############################

class File_main_core_tb_cpp:
    
    def __init__(self, Am): #integration pass?
        self.matrixOrder = Am.shape[0]
        
        try:
            self.main_string = open('Script Pipeline\\HLStemplates//main_core_tb_cpp.txt','r').read() #Gets the template
        except IOError:
            raise Exception('main_core.cpp file template not found!')
            
        output = '\nprintf("V1 = %f V\\n", outprint.a);\nprintf("V1 = %f V\\n", outprint.b);\nprintf("V1 = %f V\\n", outprint.c);\nprintf("V1 = %f V\\n", outprint.d);'
        if self.matrixOrder < 4:
            output = output[0:1+35*self.matrixOrder]
        
        position = self.main_string.find('printf("\\n");')
        position += len('printf("\\n");')
        self.main_string = self.main_string[:position] + output + self.main_string[position:]
    
    def get_main_string(self):
        return self.main_string
    
    
    
    
    
    
    
    
    
    