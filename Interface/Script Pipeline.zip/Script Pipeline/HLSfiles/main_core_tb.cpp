#include "main_core.h"

OUTPUT nodalSolver(void);

int main(){
	OUTPUT outprint;
	for(int i = 0; i < 10; i++){
		outprint = nodalSolver();
	}
	printf("\n");
printf("V1 = %f V\n", outprint.a);
printf("V1 = %f V\n", outprint.b);


	return 0;
}
